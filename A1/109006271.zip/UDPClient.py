
from socket import *
import struct
import time
import threading
clientSocket = socket(AF_INET, SOCK_DGRAM)
my_socket = socket(AF_INET, SOCK_RAW, getprotobyname('icmp'))


clientSocket.bind(('127.0.0.1', 12000))
clientSocket.settimeout(1.0)
my_socket.settimeout(1.0)

def listen():
        rec_packet, addr = my_socket.recvfrom(1024)
        icmp_header = rec_packet[20:28]
        type, code, checksum, p_id, sequence = struct.unpack('bbHHh', icmp_header)
        print("ICMP Info: type=" + str(type) + ", code=" + str(code) + " massage: destination port unreachable.")

for i in range (10):
    message = 'PING ' + str(i + 1) + " " + str(time.strftime("%H:%M:%S"))
    clientSocket.sendto(message.encode('utf-8'), ('127.0.0.1',55556))
    startThread = threading.Thread(target=listen)
    startThread.start()