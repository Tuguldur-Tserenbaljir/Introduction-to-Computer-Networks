from socket import *
import time

clientSocket = socket(AF_INET, SOCK_DGRAM)
#140.114.203.11
clientSocket.bind(('127.0.0.1', 12000))
clientSocket.settimeout(1.0)

avg_rrt = 0
packets= 0.0
total_packet = 0.0

for i  in range (10) :
    sendTime = time.time() * 1000
    message = 'PING ' + str(i + 1) + " " + str(sendTime)
    clientSocket.sendto(message.encode('utf-8'), ('127.0.0.1',55555))

    try:
        data, server = clientSocket.recvfrom(1024)
        rec_Time = time.time() * 1000
        rtt = rec_Time - sendTime
        avg_rrt = avg_rrt + rtt
        print("PING " + str(i+1) + ' ' + f"{rtt:.3f}")

    except timeout:
        print("Request times out")
        packets = packets + 1
    total_packet = total_packet + 1


print("Result:")
print("Average RTT " + f"{(avg_rrt/10)}")
print("Packet loss rate " + f"{(packets/total_packet)}")
