import socket
import time
import threading
import struct
import sys
import time

def traceroute():
    dest_addr = '140.114.89.43'  
    port = 33434
    max_hops = 30
    for ttl in range(1,max_hops+1):
        receive = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.getprotobyname('icmp'))
        send = socket.socket(socket.AF_INET, socket.SOCK_DGRAM,socket.getprotobyname('udp'))
        send.setsockopt(socket.SOL_IP, socket.IP_TTL, ttl)
        
        send.settimeout(1.0)
        receive.settimeout(1.0)
        
        receive.bind(("",port))
        sys.stdout.write(" %d." % ttl)  
        curr_addr = None
        curr_name = None
        tries = 3
        try:    
            send.sendto("".encode(),(dest_addr,port))  
        except socket.timeout:
            print("Request timed out")

        while tries > 0:
            try: 
                _, curr_addr = receive.recvfrom(512)          
                send_time = time.time() * 1000
                rec_time = time.time() * 1000
                rtt = rec_time - send_time
                curr_addr = curr_addr[0]
                try:
                    curr_name = socket.gethostbyaddr(curr_addr)[0]
                except socket.error:
                    curr_name = curr_addr
            except socket.error as errno:
                tries = tries - 1
                pass
        send.close()
        receive.close()
        

        sys.stdout.write("%s (%s) %0.3f ms\n" % (curr_name,curr_addr,rtt))

        ttl += 1
        if curr_addr == dest_addr or ttl > max_hops:
            break


if __name__ == "__main__":
    traceroute()